# koishi-plugin-hypixel-watchdog

[![npm](https://img.shields.io/npm/v/koishi-plugin-hypixel-watchdog?style=flat-square)](https://www.npmjs.com/package/koishi-plugin-hypixel-watchdog)


